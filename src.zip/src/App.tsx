import React from 'react';
import Report from './components/Report';

const App: React.FC = () => {
  return (
    <div className="App">
      <Report />
    </div>
  );
};

export default App;