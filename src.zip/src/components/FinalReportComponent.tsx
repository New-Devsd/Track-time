import {
  ContentCopy,
} from '@mui/icons-material';
import {
  Alert,
  Button,
  CardContent,
  CardHeader,
  CircularProgress,
  Snackbar,
  Typography
} from '@mui/material';
import React, { useRef, useState } from 'react';
import { RootState } from '../store/reducer';
import { useSelector } from 'react-redux';
import ReactDOM from 'react-dom';
  
const FinalReportComponent: React.FC = () => {

  const headerText = useSelector((state: RootState) => state.headerText);
  const projects = useSelector((state: RootState) => state.projects)
  const localTime = useSelector((state: RootState) => state.localTime)

  const [loading, setLoading] = useState(false)
  const [openMessage, setOpenMessage] = useState(false)

  const [htmlContent, setHtmlContent] = useState('');
  const cardRef = useRef(null);

  const handleCopy = () => {
    setLoading(true);
    const cardNode = ReactDOM.findDOMNode(cardRef.current);
  
    if (cardNode instanceof HTMLElement) {
      const content = cardNode.innerHTML;
      const textContent = content.replace(/<[^>]+>/g, '');
      const formattedText = textContent.replace(/><\/\w+>/g, '>\n')
  
      setHtmlContent(formattedText);
      navigator.clipboard.writeText(formattedText)
        .then(() => {
          setTimeout(() => {
            setLoading(false);
            setOpenMessage(true);
          }, 600);
        })
        .catch((error) => {
          setLoading(false);
          console.error('Error copying text:', error);
        });
    }
  }

  const handleClose = () => {
    setOpenMessage(false);
  }

  const formatTime = (milliseconds: number) => {
    const hours = Math.floor(milliseconds / (1000 * 60 * 60));
    const minutes = Math.floor((milliseconds % (1000 * 60 * 60)) / (1000 * 60));

    return `${hours < 10 ? '0' : ''}${hours}:${minutes < 10 ? '0' : ''}${minutes}`;
  }

  return (
    <>
      <CardHeader
        title="Daily Report"
        action={
          <Button
            variant="outlined"
            size='small'
            disabled={loading}
            onClick={handleCopy}
            startIcon={loading ? <CircularProgress size={20} /> : <ContentCopy />}
          >
            Copy Report
          </Button>
        }
      />
      <CardContent ref={cardRef}>
        <CardContent sx={{ p: 0 }} >
          <Typography variant="subtitle1">{headerText.title}</Typography>
          <Typography variant="body1">{headerText.subTitle}</Typography>
        </CardContent >
        {projects.map((project, index) => (
          <CardContent key={index} sx={{ p: 1 }}>
            <Typography variant="body1">
              <Typography variant="body1" sx={{ pl: 1 }}>{project.projectHeading}:</Typography>
              {project.task.map((task, index) => (
                <Typography variant="body2" sx={{ pl: 2 }}>{index + 1}. {task.value} </Typography>
              ))}
            </Typography>
          </CardContent>
        ))}
        <CardContent sx={{ p: 1 }}>
          <Typography variant="body2">Day Start Time: {localTime.startTime} AM</Typography>
          <Typography variant="body2">Lunch Time: {formatTime(localTime.totalLunchTime)} Minutes</Typography>
          <Typography variant="body2">Break: {formatTime(localTime.totalBreackTime)} Minutes</Typography>
          <Typography variant="body2">Day End Time: {localTime.endTime} PM</Typography>
          <Typography variant="body2">Today's Hour On Desk: {formatTime(localTime.finalTime)}</Typography>
          <Typography variant="body2">Today's Total Hours: {formatTime(localTime.totalFullTime)}</Typography>
        </CardContent>
      </CardContent>
      <Snackbar
        open={openMessage}
        autoHideDuration={6000}
        onClose={handleClose}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        <Alert onClose={handleClose} severity="success">
          Report copied successfully!
        </Alert>
      </Snackbar>
    </>
  )
}
  
  export default FinalReportComponent;